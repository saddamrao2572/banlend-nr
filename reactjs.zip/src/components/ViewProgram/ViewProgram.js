import React from 'react';
import PropTypes from 'prop-types';
import './ViewProgram.css';

const ViewProgram = () => (
  <div className="ViewProgram">
    ViewProgram Component
  </div>
);

ViewProgram.propTypes = {};

ViewProgram.defaultProps = {};

export default ViewProgram;
