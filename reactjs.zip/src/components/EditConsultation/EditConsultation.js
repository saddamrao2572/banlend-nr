import React from 'react';
import PropTypes from 'prop-types';
import './EditConsultation.css';

const EditConsultation = () => (
  <div className="EditConsultation">
    EditConsultation Component
  </div>
);

EditConsultation.propTypes = {};

EditConsultation.defaultProps = {};

export default EditConsultation;
