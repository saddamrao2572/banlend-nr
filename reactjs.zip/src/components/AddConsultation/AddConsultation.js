import React from 'react';
import PropTypes from 'prop-types';
import './AddConsultation.css';

const AddConsultation = () => (
  <div className="AddConsultation">
    AddConsultation Component
  </div>
);

AddConsultation.propTypes = {};

AddConsultation.defaultProps = {};

export default AddConsultation;
