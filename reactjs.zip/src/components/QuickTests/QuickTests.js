import React from 'react';
import PropTypes from 'prop-types';
import './QuickTests.css';

const QuickTests = () => (
  <div className="QuickTests">
    QuickTests Component
  </div>
);

QuickTests.propTypes = {};

QuickTests.defaultProps = {};

export default QuickTests;
