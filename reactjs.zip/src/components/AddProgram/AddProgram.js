import React from 'react';
import PropTypes from 'prop-types';
import './AddProgram.css';

const AddProgram = () => (
    <div className="AddProgram">

    </div>
);

AddProgram.propTypes = {};

AddProgram.defaultProps = {};

export default AddProgram;
