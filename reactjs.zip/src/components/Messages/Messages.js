import React from 'react';
import PropTypes from 'prop-types';
import './Messages.css';

const Messages = () => (
  <div className="Messages">
    Messages Component
  </div>
);

Messages.propTypes = {};

Messages.defaultProps = {};

export default Messages;
