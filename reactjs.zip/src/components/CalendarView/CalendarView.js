import React from 'react';
import PropTypes from 'prop-types';
import './CalendarView.css';

const CalendarView = () => (
  <div className="CalendarView">
    CalendarView Component
  </div>
);

CalendarView.propTypes = {};

CalendarView.defaultProps = {};

export default CalendarView;
