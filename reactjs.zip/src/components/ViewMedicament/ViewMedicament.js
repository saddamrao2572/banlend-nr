import React from 'react';
import PropTypes from 'prop-types';
import './ViewMedicament.css';

const ViewMedicament = () => (
  <div className="ViewMedicament">
    ViewMedicament Component
  </div>
);

ViewMedicament.propTypes = {};

ViewMedicament.defaultProps = {};

export default ViewMedicament;
