import React from 'react';
import PropTypes from 'prop-types';
import './Location.css';

const Location = () => (
  <div className="Location">
    Location Component
  </div>
);

Location.propTypes = {};

Location.defaultProps = {};

export default Location;
