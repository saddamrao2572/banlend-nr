import React from 'react';
import PropTypes from 'prop-types';
import './Appointements.css';

const Appointements = () => (
  <div className="Appointements">
    Appointements Component
  </div>
);

Appointements.propTypes = {};

Appointements.defaultProps = {};

export default Appointements;
