import React from 'react';
import PropTypes from 'prop-types';
import './Urgence.css';

const Urgence = () => (
  <div className="card">
  <div className="card-header">
    <strong className="card-title">Candidats</strong>
  </div>
  <div className="card-body">
    
    <table id="example1" className="table table-striped table-bordered">
    
    </table>
  </div>
</div>
);

Urgence.propTypes = {};

Urgence.defaultProps = {};

export default Urgence;
