export default class Company {
    static APP_COMPANY_NAME = "Accountt"
    static APP_COMPANY_EMAIL = "account@gmail.com"
    static APP_TIME_ZONE = "UTC+1"
    static APP_DATE_FOMMAT = "mm-dd-yyyy"
    static APP_WEBSITE = "www.accountt.com"
    static APP_TELEPHONE = "06 33 55 66"
    static APP_ADDRESS = ""
}