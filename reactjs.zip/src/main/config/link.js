export default class Link {
    static BACKEND_URL = ""
    static BACKEND_TECHNOLOGY = ""
    static BACKEND_PORT = ""
}