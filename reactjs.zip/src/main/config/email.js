export default class Email {
    static MAIL_DRIVER = "smtp"
    static MAIL_HOST = "smtp.gmail.com"
    static MAIL_PORT = "587"
    static MAIL_USERNAME = "contact@gmail.com"
    static MAIL_PASSWORD = "12345"
    static MAIL_ENCRYPTION = "ssl"
    static MAIL_FROM = "noreply@accountt"
    static MAIl_FROM_NAME = "accountt"
}