
const paymentValidation = {
    invoiceNumber: 'cc',
    paymentDate: 'cc',
    paymenMode: 'cc',
    amountReceived: 'cc',
    InvoiceBlanceDue: 'cc'
}
export default paymentValidation;