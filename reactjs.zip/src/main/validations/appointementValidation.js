const expenseValidation = {
    date: 'dd',
    name: 'd',
    amount: 'sss',
    note: 'ss',
    paymenMode: 'ss'


}
export default expenseValidation;