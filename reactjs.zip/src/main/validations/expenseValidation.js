const appointementValidation = {
    date: 'la date de rendez-vous est obligatoire',
    patient: 'adresse email est obligatoire',
    problem: 'numero de telephone est obligatoire',


}
export default appointementValidation;