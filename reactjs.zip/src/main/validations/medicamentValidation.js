
const medicamentValidation = {
    medicine_name: 'Le nom de medicamnt est obligatoire',
    company_name: 'Le nom de constructeur est obligatoire',
    group_name: 'Le groupe sanguin est obligatoire',
    description: 'La description est obligatoire',
}
export default medicamentValidation;