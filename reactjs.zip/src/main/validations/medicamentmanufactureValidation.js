const medicamentManufactureValidation = {
    name: 'la date de rendez-vous est obligatoire'

}
export default medicamentManufactureValidation;