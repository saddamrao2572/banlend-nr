
const certificateTemplateValidation = {
    name: 'Sequelize.STRING',
    content: 'Sequelize.STRING'
}
export default certificateTemplateValidation;