
const patientValidation = {
    namepatient: 'le nom de patient est obligatoire',
    emailpatient: 'ID de patientest obligatoire',
    birth: 'est obligatoire',
    telephone: 'Le téléphone de patient est obligatoire',
    gender: 'Le groupe sanguin est obligatoire',
    address: 'L\'adresse est obligatoire',
}

export default patientValidation;