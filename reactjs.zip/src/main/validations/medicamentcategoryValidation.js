const medicamentCategoryValidation = {
    name: 'la date de rendez-vous est obligatoire'


}
export default medicamentCategoryValidation;