
const prescriptionValidation = {
    prescription: 'la prescription est obligatoire'
}
export default prescriptionValidation;