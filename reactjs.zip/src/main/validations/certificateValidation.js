
const certificateValidation = {
    datee: 'date is required.',
    patient: 'Sequelize.STRING',
    content: 'Sequelize.STRING',
    patient: 'ddd'
}
export default certificateValidation;