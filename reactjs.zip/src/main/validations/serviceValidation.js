
const prescriptionValidation = {
    prescription: ' prescription is required'
}
export default prescriptionValidation;