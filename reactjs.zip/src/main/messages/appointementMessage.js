const appointementMessage = {
    add: 'Le rendez-vous a été ajouté avec succés',
    edit: 'Le rendez-vous  a été modifié avec succés',
    delete: 'Le rendez-vous  a été supprimé avec succés'
}

export default appointementMessage

