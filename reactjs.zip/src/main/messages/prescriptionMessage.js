const prescriptionMessage = {
    add: 'La prescription a été ajouté avec succés',
    edit: 'La prescription a été modifié avec succés',
    delete: 'La prescription a été supprimé avec succés'
}

export default prescriptionMessage

