const medicamentMessage = {
    add: 'Le medicament a été ajouté avec succés',
    edit: 'Le medicament a été modifié avec succés',
    delete: 'Le medicament a été supprimé avec succés'
}

export default medicamentMessage

