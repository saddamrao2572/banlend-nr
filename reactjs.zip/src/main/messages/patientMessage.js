const patientMessage = {
    add: 'Le patient a été ajouté avec succés',
    edit: 'Le patient a été modifié avec succés',
    delete: 'Le patient a été supprimé avec succés'
}

export default patientMessage

